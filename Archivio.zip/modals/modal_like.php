

<!-- Like Modal -->
<div style="z-index: 99999!important;"  class="modal fade modalbox" id="ModalLikes" data-bs-backdrop="static" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header bg-primary">
                <h3 class="modal-title text-white ">Piace a</h3>
                <a href="#" data-bs-dismiss="modal" class="text-white"><b>Chiudi</b></a>
            </div>
            <div class="modal-body p-0">
                
                <div id="likeModalContent">
                    
                </div>

            </div>
            <!-- * Card Body -->
        </div>
        <!-- * Card -->
    </div>
</div>
<!-- * Like Modal -->
