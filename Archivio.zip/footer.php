<!-- ///////////// Js Files ////////////////////  -->

<script src="<?php echo $path_url;?>/assets/js/jquery.min.js" crossorigin="anonymous"></script>

 <!-- Bootstrap -->

 <script src="<?php echo $path_url;?>/assets/js/lib/bootstrap.min.js"></script>
 <!-- Ionicons -->
 <!-- script type="module" src="https://unpkg.com/ionicons@5.5.2/dist/ionicons/ionicons.js"></script -->
 <!-- Splide -->
 <script src="<?php echo $path_url;?>/assets/js/plugins/splide/splide.min.js"></script>
 <!-- ProgressBar js -->
 <script src="<?php echo $path_url;?>/assets/js/plugins/progressbar-js/progressbar.min.js"></script>
 <!-- Mention @ Js File -->
 <!-- Base Js File -->
 <script src="<?php echo $path_url;?>/assets/js/base.js"></script>
 <!-- Functiins Js File -->
 <script src="<?php echo $path_url;?>/assets/js/functionsApp.js"></script>

<script src="<?php echo $path_url;?>/assets/js/zuck.js"></script>

<script src="<?php echo $path_url;?>/assets/js/croppie.js"></script>