<div class="section mt-2">
            <div class="card bg-dark text-white">
                <img src="assets/img/sample/photo/wide3.jpg" class="card-img overlay-img" alt="image">
                <div class="card-img-overlay">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some card text here and more natural text content.</p>
                    <p class="card-text"><small>Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>


         <div class="section mt-2">
            <div class="card">
                <img src="assets/img/sample/photo/wide2.jpg" class="card-img-top" alt="image">
                <div class="card-body">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">This is a wider card with supporting text below as a natural lead-in to
                        additional content. This content is a little bit longer.</p>
                    <p class="card-text"><small>Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>
        


        <div class="section mt-2">
            <div class="card bg-dark text-white">
                <img src="assets/img/sample/photo/wide3.jpg" class="card-img overlay-img" alt="image">
                <div class="card-img-overlay">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some card text here and more natural text content.</p>
                    <p class="card-text"><small>Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>


        <div class="section mt-2">
            <div class="card bg-dark text-white">
                <img src="assets/img/sample/photo/wide3.jpg" class="card-img overlay-img" alt="image">
                <div class="card-img-overlay">
                    <h5 class="card-title">Card title</h5>
                    <p class="card-text">Some card text here and more natural text content.</p>
                    <p class="card-text"><small>Last updated 3 mins ago</small></p>
                </div>
            </div>
        </div>


