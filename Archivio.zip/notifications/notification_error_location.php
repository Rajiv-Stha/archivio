<!-- Post add notification  -->
<div id="notification-error-location" class="notification-box">
    <div class="notification-dialog android-style">
        <div class="notification-header">
            <div class="in">
                <img src="assets/img/logo_spottat.png" alt="image" class="imaged w24">
                <strong>Spott@</strong>
                <span>Ti connette con le persone che vedi</span>
            </div>
            <a href="#" class="close-button">
                <i class="bi bi-x-lg"></i>
            </a>
        </div>
        <div class="notification-content">
            <div class="in">
                <h3 class="subtitle">Abbiamo bisogno di conoscere la tua posizione per poterti mostrare i Post e i Moments intorno a te. <br></h3>
                <div class="text">
                    La tua posizione non verrà mai condivisa con nessuno.<br>   
                </div>
            </div>
        </div>
    </div>
</div>
<!-- * Post add notification -->




