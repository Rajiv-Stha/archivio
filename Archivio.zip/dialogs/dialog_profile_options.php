<!-- Notification Spotted Dialog Block -->
<div class="modal fade dialogbox"   id="DialogProfileOptions" data-bs-backdrop="static" data-bs-dismiss="modal" tabindex="-1" role="dialog">
    <div class="modal-dialog" role="document" >
        <div class="modal-content text-center" style="box-shadow: rgba(0, 0, 0, 0.09) 0px 2px 28px 10px!important;">
            <div class="modal-footer">
                <div class="btn-list">
                    <a href="#"  onclick="goToProfile(1);" class="btn btn-text-dark btn-block text-danger" data-bs-dismiss="modal">
                        <i class="bi bi-exclamation-triangle"></i>
                        <b>Segnala</b>
                    </a>
                    <a href="#"  onclick="goToProfile(1);" class="btn btn-text-dark btn-block text-danger" data-bs-dismiss="modal">
                        <i class="bi bi-x-octagon"></i>
                        <b>Blocca</b>
                    </a>
                    <!--a href="#"  onclick="goToProfile(1);" class="btn btn-text-dark btn-block" data-bs-dismiss="modal">
                        <i class="bi bi-share-fill"></i>
                        Condividi Profilo
                    </a-->                    
                    <a href="#" class="btn btn-text btn-block" data-bs-dismiss="modal">
                       
                        Annulla
                    </a>
                </div> 

            </div>
        </div>
    </div>
</div>
<!-- * Notification Spotted Dialog Block -->