<div class="offcanvas offcanvas-bottom action-sheet" tabindex="-1" id="actionSheetShareBox" style="visibility: visible;" aria-modal="true" role="dialog">
            <div class="offcanvas-header">
                <h5 class="offcanvas-title">Share with</h5>
            </div>
            <div class="offcanvas-body">
                <div class="action-sheet-content">
                    <div class="row" style="padding: auto;">
                        <div class="col-12 text-center display-flex">
                            <a href="#" class="btn btn-icon btn-facebook p-2" data-bs-dismiss="offcanvas">
                                <i name="logo-facebook" role="img" class="bi bi-facebook" aria-label="logo facebook"></i>
                            </a>
                        
                            <a href="#" class="btn btn-icon btn-twitter p-2" data-bs-dismiss="offcanvas">
                                <i name="logo-twitter" role="img" class="bi bi-twitter" aria-label="logo twitter"></i>
                            </a>
                        
                            <a href="#" class="btn btn-icon btn-whatsapp p-2" data-bs-dismiss="offcanvas">
                                <i name="logo-whatsapp" role="img" class="bi bi-whatsapp" aria-label="logo whatsapp"></i>
                            </a>
                        </div>   
                    </div>
                </div>
            </div>
        </div>