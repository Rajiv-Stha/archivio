<div class="offcanvas offcanvas-bottom action-sheet" tabindex="-1" id="actionSheetContent">
    <div class="offcanvas-body">
        <div class="action-sheet-content">
            <div class="offcanvas-header text-center">
                <h3>Aggiungi Foto o Video</h3>
            </div>
            <div class="wide-block pb-2 pt-2">


                    <div class="custom-file-upload" id="fileUpload1">
                        <input type="file" id="fileToUpload" name="the_file" accept=".png, .jpg, .jpeg">
                        <label for="fileToUpload">
                            <span>
                                <strong>
                                    <i class="bi bi-plus-square"></i>
                                    <i class="mt-2">Inserisci Foto o Video</i>
                                </strong>
                            </span>
                        </label>
                    </div>


            </div>
        </div>
    </div>
</div>
