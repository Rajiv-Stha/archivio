<!-- Action sheet media -->
<div class="offcanvas offcanvas-bottom action-sheet" tabindex="-1" id="actionSheetAddTextStories" style="z-index: 9999999;">
    <div class="offcanvas-body">
        <div class="action-sheet-content">
            <div class="offcanvas-header text-center">
                <h3>Lascia uno Spot</h3>
            </div>
            <div class="wide-block pb-2 pt-2">

                <form>
                    <div class="custom-file-upload" id="fileUpload1">
                        <textarea class="form-control" id="to" name="spottArea" placeholder="Chi hai avvistato oggi?" rows="4"></textarea>
                        
                    </div>
                </form>

            </div>
        </div>
    </div>
</div>
<!-- * Action sheet media --> 