

        <ul class="listview image-listview media mb-2">
            <li class="bg-gr">
                <a href="#" class="item">
                    <div class="imageWrapper">
                        <img src="assets/img/sample/photo/1.jpg" alt="image" class="imaged w55">
                    </div>
                    <div class="in">
                        <div>
                            <span class="text-truncate">Crystal Bar, Caposele</span>
                            <div>
                                <span class="text-truncate text-gr">vitale_89</span>
                                <span class="text-muted text-truncate"> ha lasciato uno Spot qui</span>
                            </div>
                        </div>
                        <span class="text-muted">10:30</span>
                    </div>
                </a>
            </li>
            
            <li class="">
                <a href="#" class="item">
                    <div class="imageWrapper">
                        <img src="assets/img/sample/photo/1.jpg" alt="image" class="imaged w55">
                    </div>
                    <div class="in">
                        <div>
                            Piazzale Kennedy, Avellino
                            <div>
                                <span class="text-gr">vincenzo_russomanno</span>
                                <span class="text-muted"> ha lasciato uno Spot qui</span>
                            </div>
                        </div>
                        <span class="text-muted">10:30</span>
                    </div>
                </a>
            </li>
        </ul>