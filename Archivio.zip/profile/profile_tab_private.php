<div class="text-center pt-5">
    <img src="assets/img/EmptyStatePrivateProfile.png" class="img-fluid w-50 pt-5">
    <div class="p-3">
        <h3>Account Privato</h3>
        <p>Inizia a seguire questo account per vedere i suoi Spot e Luoghi favoriti</p>
    </div>
</div>